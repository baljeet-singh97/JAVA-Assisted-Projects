//When we use static method we can call the method without creating object of the class
package methods;



public class StaticMethod 
{
		public static void main(String args[])
		{
			//No object of class is created
	    		display();
		}

		static void display()
		{
			System.out.println("Use of static method");
		}
}
	
	
