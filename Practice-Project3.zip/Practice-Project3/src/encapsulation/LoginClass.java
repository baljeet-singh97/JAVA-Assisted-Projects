package encapsulation;

public class LoginClass {
	
	public static void main(String[] args) {
		
		//when data comes from server we need to store and pass it to another class
		//we use encapsulation, serializable, tostring method, constructors
		
	}

}
