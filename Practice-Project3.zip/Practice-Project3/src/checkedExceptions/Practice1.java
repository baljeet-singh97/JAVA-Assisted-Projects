package checkedExceptions;


public class Practice1 {
	
	public static void main(String[] args) {
		
		
		//Exception in thread "main" java.lang.Error: Unresolved compilation problem: 
		//Unhandled exception type InterruptedException
		Thread.sleep(1000);
		
	}

}
