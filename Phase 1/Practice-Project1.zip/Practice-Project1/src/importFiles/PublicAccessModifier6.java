package importFiles;

public class PublicAccessModifier6 {
	public void out()
	{
		System.out.println("accessing public specifier");
	}
}
